import 'dart:async';
import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import '../webrtc/base_connection_manager.dart';
import 'media_transfer_service.dart';
import 'signaling_service.dart';

class WebRTCService extends BaseConnectionManager {
  final SignalingService _signalingService;
  final MediaTransferService _mediaTransferService;
  final String _localPeerId;
  final Map<String, RTCPeerConnection> _peers = {};
  final Map<String, RTCDataChannel> _dataChannels = {};
  MediaStream? _localStream;
  final Map<String, MediaStream> _remoteStreams = {};

  WebRTCService({
    required SignalingService signalingService,
    required MediaTransferService mediaTransferService,
    required String localPeerId,
    void Function(String message)? onLog,
    void Function(String error)? onError,
    void Function(MediaStream? stream)? onStreamChanged,
    void Function(String mediaType, Uint8List data)? onMediaReceived,
    void Function(String command)? onCommandReceived,
    VoidCallback? onStateChange,
  })  : _signalingService = signalingService,
        _mediaTransferService = mediaTransferService,
        _localPeerId = localPeerId,
        super(
          onLog: onLog,
          onError: onError,
          onStreamChanged: onStreamChanged,
          onMediaReceived: onMediaReceived,
          onCommandReceived: onCommandReceived,
          onStateChange: onStateChange,
        ) {
    _setupSignalingHandlers();
  }

  /// Initialize the WebRTC service
  Future<void> initialize() async {
    try {
      await _signalingService.connect();
      _log('WebRTC service initialized');
    } catch (e) {
      _logError('Failed to initialize WebRTC service: $e');
      rethrow;
    }
  }

  /// Set up signaling message handlers
  void _setupSignalingHandlers() {
    _signalingService.on('offer', _handleOffer);
    _signalingService.on('answer', _handleAnswer);
    _signalingService.on('ice-candidate', _handleIncomingIceCandidate);
    _signalingService.on('disconnect', _handleDisconnect);
  }

  /// Create a new peer connection
  Future<RTCPeerConnection> _createPeerConnection(String peerId) async {
    try {
      final config = {
        'iceServers': [
          {'urls': 'stun:stun.l.google.com:19302'},
        ],
      };

      final pc = await super.createPeerConnection(config);
      _peers[peerId] = pc;
      return pc;
    } catch (e) {
      _logError('Failed to create peer connection: $e');
      rethrow;
    }
  }

  /// Set up a data channel for a peer
  Future<RTCDataChannel> _createDataChannel(
    RTCPeerConnection pc,
    String label, {
    RTCDataChannelInit? options,
  }) async {
    try {
      final channel =
          await pc.createDataChannel(label, options ?? RTCDataChannelInit());
      _dataChannels[label] = channel;
      _setupDataChannel(channel);
      return channel;
    } catch (e) {
      _logError('Failed to create data channel: $e');
      rethrow;
    }
  }

  /// Configure listeners for a newly created or received RTCDataChannel
  void _setupDataChannel(RTCDataChannel channel) {
    // The label may be nullable in the WebRTC interface; make it non-nullable for our maps/logging.
    final label = channel.label ?? 'unknown';

    _log('Setting up data channel: $label');

    // Keep track of the channel by its label for later use
    _dataChannels[label] = channel;

    // React to state changes
    channel.onDataChannelState = (state) {
      _log('Data channel ($label) state changed to: $state');

      if (state == RTCDataChannelState.RTCDataChannelClosed) {
        _dataChannels.remove(label);
      }

      _onConnectionStateChanged();
    };

    // Handle incoming messages (text or binary)
    channel.onMessage = (RTCDataChannelMessage message) {
      if (message.isBinary) {
        _handleBinaryMessage(label, message.binary);
      } else {
        _handleTextMessage(label, message.text);
      }
    };
  }

  @override
  void _handleIceCandidate(RTCPeerConnection pc, RTCIceCandidate candidate) {
    try {
      final peerEntry = _peers.entries.firstWhere(
        (entry) => entry.value == pc,
        orElse: () => throw Exception('Peer not found for connection'),
      );

      _signalingService.send('ice-candidate', {
        'from': _localPeerId,
        'to': peerEntry.key,
        'candidate': candidate.candidate,
        'sdpMid': candidate.sdpMid,
        'sdpMLineIndex': candidate.sdpMLineIndex,
      });
    } catch (e) {
      _logError('Failed to handle ICE candidate: $e');
    }
  }

  @override
  void _onConnectionStateChanged() {
    onStateChange?.call();
  }

  @override
  void _handleTrackEvent(RTCTrackEvent event) {
    // if (event.streams.isNotEmpty) {
      
    //   final stream = event.streams.first;
    //   final peerId = _peers.entries
    //       .firstWhere((entry) =>
    //           entry.value == event.receiver?.transport?.webRtcPeerConnection)
    //       .key;

    //   _remoteStreams[peerId] = stream;
    //   onStreamChanged?.call(stream);
    // }
  }

  @override
  void _handleIceConnectionState(RTCIceConnectionState state) {
    _log('ICE connection state changed: $state');
    if (state == RTCIceConnectionState.RTCIceConnectionStateDisconnected ||
        state == RTCIceConnectionState.RTCIceConnectionStateFailed) {
      _onConnectionStateChanged();
    }
  }

  @override
  void _handleTextMessage(String label, String message) {
    try {
      final data = message;
      if (data.startsWith('command:')) {
        final command = data.substring(8);
        onCommandReceived?.call(command);
      }
      _log('Received text message on channel $label: $data');
    } catch (e) {
      _logError('Error handling text message: $e');
    }
  }

  @override
  void _handleBinaryMessage(String label, Uint8List data) {
    try {
      onMediaReceived?.call('binary', data);
      _log('Received binary message (${data.length} bytes) on channel $label');
    } catch (e) {
      _logError('Error handling binary message: $e');
    }
  }

  /// Send an offer to a peer
  Future<void> sendOffer(String peerId) async {
    try {
      final pc = await _createPeerConnection(peerId);
      await _createDataChannel(pc, 'data');

      final offer = await pc.createOffer();
      await pc.setLocalDescription(offer);

      await _signalingService.send('offer', {
        'from': _localPeerId,
        'to': peerId,
        'sdp': offer.sdp,
        'type': offer.type,
      });

      _log('Sent offer to $peerId');
    } catch (e) {
      _logError('Failed to send offer: $e');
      rethrow;
    }
  }

  /// Handle an incoming offer
  Future<void> _handleOffer(dynamic data) async {
    try {
      final from = data['from'] as String;
      final sdp = data['sdp'] as String;

      _log('Received offer from $from');

      final pc = await _createPeerConnection(from);
      await pc.setRemoteDescription(RTCSessionDescription(sdp, 'offer'));

      final answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);

      await _signalingService.send('answer', {
        'from': _localPeerId,
        'to': from,
        'sdp': answer.sdp,
        'type': answer.type,
      });

      _log('Sent answer to $from');
    } catch (e) {
      _logError('Failed to handle offer: $e');
      rethrow;
    }
  }

  /// Handle an incoming answer
  Future<void> _handleAnswer(dynamic data) async {
    try {
      final from = data['from'] as String;
      final sdp = data['sdp'] as String;

      _log('Received answer from $from');

      final pc = _peers[from];
      if (pc != null) {
        await pc.setRemoteDescription(RTCSessionDescription(sdp, 'answer'));
        _log('Set remote description from $from');
      }
    } catch (e) {
      _logError('Failed to handle answer: $e');
      rethrow;
    }
  }

  /// Handle incoming ICE candidates from signaling
  Future<void> _handleIncomingIceCandidate(dynamic data) async {
    try {
      final from = data['from'] as String;
      final candidate = data['candidate'] as String;
      final sdpMid = data['sdpMid'] as String?;
      final sdpMLineIndex = data['sdpMLineIndex'] as int?;

      if (sdpMid == null || sdpMLineIndex == null) {
        _logError('Invalid ICE candidate: missing sdpMid or sdpMLineIndex');
        return;
      }

      final pc = _peers[from];
      if (pc != null) {
        await pc.addCandidate(RTCIceCandidate(
          candidate,
          sdpMid,
          sdpMLineIndex,
        ));
        _log('Added ICE candidate from $from');
      }
    } catch (e) {
      _logError('Failed to handle ICE candidate: $e');
    }
  }

  /// Handle peer disconnection
  Future<void> _handleDisconnect(dynamic data) async {
    try {
      final peerId = data['peerId'] as String;
      await _closePeer(peerId);
      _log('Peer disconnected: $peerId');
    } catch (e) {
      _logError('Failed to handle disconnect: $e');
    }
  }

  /// Close a peer connection
  Future<void> _closePeer(String peerId) async {
    try {
      final pc = _peers.remove(peerId);
      if (pc != null) {
        await pc.close();
        _dataChannels.removeWhere((_, channel) => channel.id == peerId);
        _remoteStreams.remove(peerId);
        onStateChange?.call();
      }
    } catch (e) {
      _logError('Failed to close peer $peerId: $e');
    }
  }

  /// Send data to a peer
  @override
  Future<void> sendData(String data, {String? label}) async {
    try {
      final channel = label != null
          ? _dataChannels[label]
          : _dataChannels.values.firstWhere(
              (ch) => ch.state == RTCDataChannelState.RTCDataChannelOpen,
              orElse: () => throw Exception('No open data channels'),
            );

      if (channel != null) {
        channel.send(RTCDataChannelMessage(data));
      } else {
        throw Exception('Data channel not found');
      }
    } catch (e) {
      _logError('Failed to send data: $e');
      rethrow;
    }
  }

  /// Send binary data to a peer
  @override
  Future<void> sendBinary(Uint8List data, {String? label}) async {
    try {
      final channel = label != null
          ? _dataChannels[label]
          : _dataChannels.values.firstWhere(
              (ch) => ch.state == RTCDataChannelState.RTCDataChannelOpen,
              orElse: () => throw Exception('No open data channels'),
            );

      if (channel != null) {
        channel.send(RTCDataChannelMessage.fromBinary(data));
      } else {
        throw Exception('Data channel not found');
      }
    } catch (e) {
      _logError('Failed to send binary data: $e');
      rethrow;
    }
  }

  @override
  Future<void> dispose() async {
    await super.dispose();

    for (final pc in _peers.values) {
      await pc.close();
    }

    _peers.clear();
    _dataChannels.clear();
    _remoteStreams.clear();

    if (_localStream != null) {
      for (final track in _localStream!.getTracks()) {
        await track.stop();
      }
      _localStream = null;
    }

    await _signalingService.dispose();
    _log('WebRTC service disposed');
  }

  /// Log a message
  void _log(String message) {
    onLog?.call('[WebRTCService] $message');
  }

  /// Log an error
  void _logError(String message) {
    onError?.call('[WebRTCService] $message');
    _log('ERROR: $message');
  }
}
