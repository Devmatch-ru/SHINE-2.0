import 'package:get_it/get_it.dart';
import 'package:uuid/uuid.dart';
import 'signaling_service.dart';
import '../trash/media_transfer_service.dart';
import 'webrtc_service.dart';

class ServiceLocator {
  static final GetIt _locator = GetIt.instance;

  static T get<T extends Object>() => _locator.get<T>();

  static Future<void> setup() async {
    // Register services as singletons
    _locator.registerLazySingleton<MediaTransferService>(
      () => MediaTransferService(
        onLog: (message) => print('[MediaTransfer] $message'),
        onError: (error) => print('[MediaTransfer] ERROR: $error'),
      ),
    );

    // Register signaling service with WebSocket URL
    _locator.registerLazySingleton<SignalingService>(
      () => SignalingService(
        serverUrl:
            'ws://your-signaling-server.com/ws', // Replace with actual server URL
        onLog: (message) => print('[Signaling] $message'),
        onError: (error) => print('[Signaling] ERROR: $error'),
        onConnected: () => print('[Signaling] Connected to server'),
        onDisconnected: () => print('[Signaling] Disconnected from server'),
      ),
    );

    // Generate a unique ID for this device
    final deviceId = await _getDeviceId();

    // Register WebRTC service
    _locator.registerLazySingleton<WebRTCService>(
      () => WebRTCService(
        signalingService: _locator<SignalingService>(),
        mediaTransferService: _locator<MediaTransferService>(),
        localPeerId: deviceId,
        onLog: (message) => print('[WebRTC] $message'),
        onError: (error) => print('[WebRTC] ERROR: $error'),
        onStreamChanged: (stream) {
          print('Stream changed: ${stream?.id}');
          // Handle stream change
        },
        onMediaReceived: (type, data) {
          print('Received media: $type (${data.length} bytes)');
          // Handle received media
        },
        onCommandReceived: (command) {
          print('Received command: $command');
          // Handle received command
        },
      ),
    );
  }

  /// Get or generate a unique device ID
  static Future<String> _getDeviceId() async {
    // TODO: Implement actual device ID generation/storage
    // For now, use a random UUID
    return const Uuid().v4();
  }

  /// Dispose all services
  static Future<void> dispose() async {
    await _locator.reset();
  }
}

// Extension to make it easier to access services
extension GetItX on GetIt {
  T call<T extends Object>() => get<T>();
}

// Global service locator instance
final sl = ServiceLocator();
