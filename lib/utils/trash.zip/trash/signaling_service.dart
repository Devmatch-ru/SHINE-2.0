import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:http/http.dart' as http;
import 'package:uuid/uuid.dart';

class SignalingService {
  final String _serverUrl;
  WebSocketChannel? _channel;
  final Map<String, Completer<dynamic>> _pendingRequests = {};
  final Map<String, Function(dynamic)> _handlers = {};

  final void Function(String message)? onLog;
  final void Function(String error)? onError;
  final void Function()? onConnected;
  final void Function()? onDisconnected;
  final void Function(dynamic message)? onMessage;

  SignalingService({
    required String serverUrl,
    this.onLog,
    this.onError,
    this.onConnected,
    this.onDisconnected,
    this.onMessage,
  }) : _serverUrl = serverUrl;

  /// Connect to the signaling server
  Future<void> connect() async {
    try {
      _log('Connecting to signaling server: $_serverUrl');
      _channel = WebSocketChannel.connect(Uri.parse(_serverUrl));

      _channel!.stream.listen(
        _handleMessage,
        onError: (error) {
          _logError('WebSocket error: $error');
          _reconnect();
        },
        onDone: () {
          _log('WebSocket connection closed');
          onDisconnected?.call();
          _reconnect();
        },
      );

      _log('Connected to signaling server');
      onConnected?.call();
    } catch (e) {
      _logError('Failed to connect to signaling server: $e');
      rethrow;
    }
  }

  /// Disconnect from the signaling server
  Future<void> disconnect() async {
    await _channel?.sink.close();
    _channel = null;
    _log('Disconnected from signaling server');
  }

  /// Send a message to the signaling server
  Future<dynamic> send(String type, [Map<String, dynamic>? data]) async {
    if (_channel == null) {
      throw Exception('Not connected to signaling server');
    }

    final requestId = const Uuid().v4();
    final message = {
      'id': requestId,
      'type': type,
      'data': data ?? {},
    };

    final completer = Completer<dynamic>();
    _pendingRequests[requestId] = completer;

    try {
      _log('Sending message: $message');
      _channel!.sink.add(jsonEncode(message));

      // Set a timeout for the response
      return await completer.future.timeout(
        const Duration(seconds: 10),
        onTimeout: () {
          _pendingRequests.remove(requestId);
          throw TimeoutException('Signaling server response timeout');
        },
      );
    } catch (e) {
      _pendingRequests.remove(requestId);
      rethrow;
    }
  }

  /// Register a message handler
  void on(String type, Function(dynamic) handler) {
    _handlers[type] = handler;
  }

  /// Handle incoming WebSocket messages
  void _handleMessage(dynamic message) {
    try {
      _log('Received message: $message');
      final data = jsonDecode(message);

      // Handle message callbacks
      onMessage?.call(data);

      // Handle pending requests
      if (data['id'] != null && _pendingRequests.containsKey(data['id'])) {
        _pendingRequests[data['id']]!.complete(data['data']);
        _pendingRequests.remove(data['id']);
        return;
      }

      // Handle registered message handlers
      if (data['type'] != null && _handlers.containsKey(data['type'])) {
        _handlers[data['type']]!(data['data']);
      }
    } catch (e) {
      _logError('Error handling message: $e');
    }
  }

  /// Reconnect to the signaling server with exponential backoff
  void _reconnect() {
    int attempts = 0;
    const maxAttempts = 5;

    Future.delayed(const Duration(seconds: 1), () async {
      while (attempts < maxAttempts) {
        try {
          await connect();
          _log('Successfully reconnected to signaling server');
          return;
        } catch (e) {
          attempts++;
          final delay = Duration(seconds: pow(2, attempts).toInt());
          _logError(
              'Reconnection attempt $attempts failed, retrying in ${delay.inSeconds}s...');
          await Future.delayed(delay);
        }
      }
      _logError('Failed to reconnect after $maxAttempts attempts');
    });
  }

  /// Log a message
  void _log(String message) {
    onLog?.call('[SignalingService] $message');
  }

  /// Log an error
  void _logError(String message) {
    onError?.call('[SignalingService] $message');
    _log('ERROR: $message');
  }

  /// Clean up resources
  Future<void> dispose() async {
    await disconnect();
    _pendingRequests.clear();
    _handlers.clear();
  }
}
