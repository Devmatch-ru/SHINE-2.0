import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:gallery_saver_plus/gallery_saver.dart';
import 'package:flutter/foundation.dart';

class MediaTransferService {
  static const int _maxChunkSize = 16 * 1024; // 16KB chunks
  static const int _maxRetries = 3;
  static const int _chunkDelayMs = 50;

  final void Function(String message)? onLog;
  final void Function(String error)? onError;
  final void Function(String fileName, String mediaType, int sentChunks,
      int totalChunks, bool isCompleted)? onTransferProgress;

  MediaTransferService({
    this.onLog,
    this.onError,
    this.onTransferProgress,
  });

  Future<String?> saveToGallery(String filePath, {bool isVideo = false}) async {
    try {
      bool? result;

      if (isVideo) {
        result = await GallerySaver.saveVideo(
          filePath,
          albumName: 'SHINE',
          toDcim: true,
        );
      } else {
        result = await GallerySaver.saveImage(
          filePath,
          albumName: 'SHINE',
          toDcim: true,
        );
      }

      if (result == true) {
        onLog?.call('Media saved to gallery: $filePath');
        return filePath;
      } else {
        throw Exception('Failed to save ${isVideo ? 'video' : 'image'} to gallery');
      }
    } catch (e) {
      _logError('Error saving to gallery: $e');
      rethrow;
    }
  }


  /// Split data into chunks for transfer
  List<Uint8List> chunkData(Uint8List data, {int chunkSize = _maxChunkSize}) {
    final chunks = <Uint8List>[];
    int offset = 0;

    while (offset < data.length) {
      final end =
          (offset + chunkSize < data.length) ? offset + chunkSize : data.length;
      chunks.add(data.sublist(offset, end));
      offset = end;
    }

    return chunks;
  }

  /// Save received chunks to a file
  Future<File> saveChunksToFile(
      List<Uint8List> chunks, String fileName, String extension) async {
    try {
      final directory = await getTemporaryDirectory();
      final file = File('${directory.path}/$fileName.$extension');

      final sink = file.openWrite();
      for (final chunk in chunks) {
        sink.add(chunk);
      }
      await sink.close();

      onLog?.call('File saved: ${file.path}');
      return file;
    } catch (e) {
      _logError('Error saving file: $e');
      rethrow;
    }
  }

  /// Get a temporary file path
  Future<String> getTempFilePath(String fileName, String extension) async {
    try {
      final directory = await getTemporaryDirectory();
      return '${directory.path}/$fileName.$extension';
    } catch (e) {
      _logError('Error getting temp file path: $e');
      rethrow;
    }
  }

  Future<String> fileToBase64(String filePath) async {
    try {
      final file = File(filePath);
      final bytes = await file.readAsBytes();
      return base64Encode(bytes);
    } catch (e) {
      _logError('Error converting file to base64: $e');
      rethrow;
    }
  }

  void _logError(String message) {
    onError?.call(message);
    onLog?.call('ERROR: $message');
  }

  Future<void> cleanupTempFiles(List<String> filePaths) async {
    try {
      for (final path in filePaths) {
        final file = File(path);
        if (await file.exists()) {
          await file.delete();
        }
      }
      onLog?.call('Cleaned up temporary files');
    } catch (e) {
      _logError('Error cleaning up temp files: $e');
    }
  }
}
